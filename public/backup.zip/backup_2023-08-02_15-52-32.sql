-- --------------------------------------------------------
-- Estructura de tabla para cajas
-- --------------------------------------------------------

CREATE TABLE `cajas` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `monto_inicial` decimal(10,2) NOT NULL,
  `fecha_apertura` datetime NOT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `id_usuario` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_usuario_caja` (`id_usuario`),
  CONSTRAINT `fk_usuario_caja` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para cajas
-- --------------------------------------------------------

INSERT INTO `cajas` VALUES ('1', '100000.00', '2023-08-02 13:10:11', '1', '2023-08-02 13:10:11', '2023-08-02 13:10:11', '1');

-- --------------------------------------------------------
-- Estructura de tabla para clientes
-- --------------------------------------------------------

CREATE TABLE `clientes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `identidad` varchar(50) NOT NULL,
  `num_identidad` varchar(50) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `apellido` varchar(150) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `whatsapp` varchar(20) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `direccion` text NOT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `num_identidad` (`num_identidad`),
  UNIQUE KEY `telefono` (`telefono`),
  UNIQUE KEY `whatsapp` (`whatsapp`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para clientes
-- --------------------------------------------------------

INSERT INTO `clientes` VALUES ('1', 'DNI', '133244435', 'ANGEL', 'SIFUENTES', '99878798799', '988979898987', 'info@angelsifuentes.net', 'peru', '1', '2023-08-02 13:07:19', '2023-08-02 13:07:19');

-- --------------------------------------------------------
-- Estructura de tabla para configuracion
-- --------------------------------------------------------

CREATE TABLE `configuracion` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `identidad` varchar(20) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `direccion` text NOT NULL,
  `mensaje` text DEFAULT NULL,
  `tasa_interes` int(11) NOT NULL,
  `cuotas` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identidad` (`identidad`),
  UNIQUE KEY `telefono` (`telefono`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para configuracion
-- --------------------------------------------------------

INSERT INTO `configuracion` VALUES ('1', '123456789', 'VIDA INFORMÁTICO', '900897537', 'info@angelsifuentes.net', 'Perú', 'GRACIAS POR ADQUIRIR EL CURSO', '10', '18', '2023-08-02 13:01:57', '2023-08-02 13:01:57');

-- --------------------------------------------------------
-- Estructura de tabla para detalle_prestamos
-- --------------------------------------------------------

CREATE TABLE `detalle_prestamos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cuota` int(11) NOT NULL,
  `fecha_venc` date NOT NULL,
  `importe_cuota` decimal(10,2) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `id_prestamo` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_prestamos` (`id_prestamo`),
  CONSTRAINT `fk_prestamos` FOREIGN KEY (`id_prestamo`) REFERENCES `prestamos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para detalle_prestamos
-- --------------------------------------------------------

INSERT INTO `detalle_prestamos` VALUES ('1', '1', '2023-09-02', '220.00', '1', '2023-08-02 13:10:25', '2023-08-02 13:10:25', '1');
INSERT INTO `detalle_prestamos` VALUES ('2', '2', '2023-10-02', '220.00', '1', '2023-08-02 13:10:25', '2023-08-02 13:10:25', '1');
INSERT INTO `detalle_prestamos` VALUES ('3', '3', '2023-11-02', '220.00', '1', '2023-08-02 13:10:25', '2023-08-02 13:10:25', '1');
INSERT INTO `detalle_prestamos` VALUES ('4', '4', '2023-12-02', '220.00', '1', '2023-08-02 13:10:25', '2023-08-02 13:10:25', '1');
INSERT INTO `detalle_prestamos` VALUES ('5', '5', '2024-01-02', '220.00', '1', '2023-08-02 13:10:25', '2023-08-02 13:10:25', '1');

-- --------------------------------------------------------
-- Estructura de tabla para migrations
-- --------------------------------------------------------

CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para migrations
-- --------------------------------------------------------

INSERT INTO `migrations` VALUES ('95', '2023-06-26-145832', 'App\Database\Migrations\Admin', 'default', 'App', '1690999260', '1');
INSERT INTO `migrations` VALUES ('96', '2023-06-26-150959', 'App\Database\Migrations\Permisos', 'default', 'App', '1690999260', '1');
INSERT INTO `migrations` VALUES ('97', '2023-06-26-151017', 'App\Database\Migrations\Roles', 'default', 'App', '1690999260', '1');
INSERT INTO `migrations` VALUES ('98', '2023-06-26-151033', 'App\Database\Migrations\Usuarios', 'default', 'App', '1690999260', '1');
INSERT INTO `migrations` VALUES ('99', '2023-06-26-151046', 'App\Database\Migrations\Cajas', 'default', 'App', '1690999260', '1');
INSERT INTO `migrations` VALUES ('100', '2023-06-26-151051', 'App\Database\Migrations\Clientes', 'default', 'App', '1690999260', '1');
INSERT INTO `migrations` VALUES ('101', '2023-06-26-151104', 'App\Database\Migrations\Prestamos', 'default', 'App', '1690999260', '1');
INSERT INTO `migrations` VALUES ('102', '2023-06-26-151116', 'App\Database\Migrations\DetallePrestamos', 'default', 'App', '1690999260', '1');

-- --------------------------------------------------------
-- Estructura de tabla para permisos
-- --------------------------------------------------------

CREATE TABLE `permisos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `modulo` varchar(150) NOT NULL,
  `campos` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para permisos
-- --------------------------------------------------------

INSERT INTO `permisos` VALUES ('1', 'usuarios', '["listar usuarios","nuevo usuario","editar usuario","eliminar usuario"]', '2023-08-02 13:01:57', '2023-08-02 13:01:57');
INSERT INTO `permisos` VALUES ('2', 'configuracion', '["actualizar empresa","backup"]', '2023-08-02 13:01:57', '2023-08-02 13:01:57');
INSERT INTO `permisos` VALUES ('3', 'roles', '["listar roles","nuevo rol","editar rol","eliminar rol"]', '2023-08-02 13:01:57', '2023-08-02 13:01:57');
INSERT INTO `permisos` VALUES ('4', 'clientes', '["listar clientes","nuevo cliente","editar cliente","eliminar cliente"]', '2023-08-02 13:01:57', '2023-08-02 13:01:57');
INSERT INTO `permisos` VALUES ('5', 'prestamos', '["nuevo prestamo","historial prestamos","ver prestamo","eliminar prestamo","abono prestamo"]', '2023-08-02 13:01:57', '2023-08-02 13:01:57');
INSERT INTO `permisos` VALUES ('6', 'cajas', '["ver saldo"]', '2023-08-02 13:01:57', '2023-08-02 13:01:57');
INSERT INTO `permisos` VALUES ('7', 'reportes', '["pdf prestamos","excel prestamos"]', '2023-08-02 13:01:57', '2023-08-02 13:01:57');

-- --------------------------------------------------------
-- Estructura de tabla para prestamos
-- --------------------------------------------------------

CREATE TABLE `prestamos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `importe` decimal(10,2) NOT NULL,
  `modalidad` varchar(50) NOT NULL,
  `tasa_interes` decimal(10,2) NOT NULL,
  `cuotas` int(11) NOT NULL,
  `fecha` datetime NOT NULL,
  `fecha_venc` date DEFAULT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `id_cliente` int(11) unsigned NOT NULL,
  `id_usuario` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_clientes` (`id_cliente`),
  KEY `fk_usuarios` (`id_usuario`),
  CONSTRAINT `fk_clientes` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_usuarios` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para prestamos
-- --------------------------------------------------------

INSERT INTO `prestamos` VALUES ('1', '1000.00', 'MENSUAL', '10.00', '5', '2023-08-02 13:10:25', '2023-09-02', '1', '2023-08-02 13:10:25', '2023-08-02 13:10:25', '1', '1');

-- --------------------------------------------------------
-- Estructura de tabla para roles
-- --------------------------------------------------------

CREATE TABLE `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `permisos` text DEFAULT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para roles
-- --------------------------------------------------------

INSERT INTO `roles` VALUES ('1', 'ADMINISTRADOR', '["listar usuarios","nuevo usuario","editar usuario","eliminar usuario","actualizar empresa","backup","listar roles","nuevo rol","editar rol","eliminar rol","listar clientes","nuevo cliente","editar cliente","eliminar cliente","nuevo prestamo","historial prestamos","ver prestamo","eliminar prestamo","abono prestamo","ver saldo","pdf prestamos","excel prestamos"]', '1', '2023-08-02 13:01:57', '2023-08-02 13:01:57');

-- --------------------------------------------------------
-- Estructura de tabla para usuarios
-- --------------------------------------------------------

CREATE TABLE `usuarios` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `apellido` varchar(150) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `direccion` text NOT NULL,
  `clave` varchar(200) NOT NULL,
  `perfil` varchar(100) DEFAULT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `token` varchar(100) DEFAULT NULL,
  `verify` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `id_rol` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `telefono` (`telefono`),
  UNIQUE KEY `correo` (`correo`),
  KEY `fk_roles` (`id_rol`),
  CONSTRAINT `fk_roles` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para usuarios
-- --------------------------------------------------------

INSERT INTO `usuarios` VALUES ('1', 'ANGEL EDIT', 'SIFUENTES', '900897537', 'lovenaju2@gmail.com', 'Perú', '$2y$10$v2klxxQLSlxS6b.8NOwBe.uTEX5lsBIsa3hHQAYsnzhSW.oIje1lC', '1.png', '1', 'bb9c4bfaf3ad5ec3080d2bdb2a176517', '1', '2023-08-02 13:01:57', '2023-08-02 15:25:45', '1');
INSERT INTO `usuarios` VALUES ('2', 'SEGUNDO USER', 'USUARIO', '998998987987', 'segundo@gmail.com', 'PERU', '$2y$10$BM7o0hYAa4yLCNkxTHMoku.iCNt77PLeIvprvt8GpNRQq/QiYtzwq', '', '1', '', '0', '2023-08-02 14:36:52', '2023-08-02 14:37:09', '1');

